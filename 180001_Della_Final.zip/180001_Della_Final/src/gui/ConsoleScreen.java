package gui;

import java.awt.*;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;

import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

import control.Controller;
import model.ActionItem;
import model.ActionItemManager;

/**
 * <p>
 * Title: ConsoleScreen
 * </p>
 *
 * <p>
 * Description:  A manually generated action item screen for Della
 * </p>
 *
 * <p>
 * Copyright: Copyright � 2007
 * </p>
 *
 * @author Lynn Robert Carter
 * Many thanks to Harry Sameshima for his original work.
 * @version 1.00
 * @version Della00
 * @co-author Garima Gautam
 * Date- Jan 16, 2021
 * Role- Analyzed the code and created an XML file. 
 * @version Della10
 * @co-author Garima Gautam
 * Date- Feb 07, 2021
 * Role- Completed the user interface of all tabs and functionality of each element
 * used in the gui(update, create, clear, delete, add, remove, sorting etc.)  
 * 
 */
public class ConsoleScreen extends JPanel {
	//---------------------------------------------------------------------------------------------------------------------
	// Console Screen constants

	//---------------------------------------------------------------------------------------------------------------------
	// Console Screen attributes

	//---------------------------------------------------------------------------------------------------------------------
	// Console Screen GUI elements
	JLabel consoleLabel = new JLabel();
	JLabel memLabel = new JLabel();
	JLabel memValueLabel = new JLabel();
	JLabel teamValueLabel = new JLabel();
	ActionItemScreen ais = new ActionItemScreen();
	JLabel copyrightLabel = new JLabel();
	JLabel selectedLabel = new JLabel();
	JLabel nameLabel = new JLabel();
	JTextField nameTextField = new JTextField();
	JLabel descriptionLabel = new JLabel();
	JScrollPane descriptionScrollPane = new JScrollPane();
	JTextArea descriptionTextArea = new JTextArea();
	JLabel resolutionLabel = new JLabel();
	JScrollPane resolutionScrollPane = new JScrollPane();
	JTextArea resolutionTextArea = new JTextArea();
	JLabel datesLabel = new JLabel();
	JLabel creationLabel = new JLabel();
	JLabel creationValueLabel = new JLabel();
	JLabel statusValueLabel = new JLabel();
	JLabel dueDateLabel = new JLabel();
	JTextField dueDateTextField = new JTextField();
	JLabel formatLabel = new JLabel();
	JLabel actionItemLabel2 = new JLabel();
	JLabel teamLabel = new JLabel();
	JLabel statusLabel = new JLabel();
	public static final String[] dir = {"Small to Large", "Large to Small"};
	public static final String[] fdir = {"None", "Due Date", "Creation Date", "Assigned Member", "Assigned Team"};
	public static final String[] sdir = {"None", "Due Date", "Creation Date", "Assigned Member", "Assigned Team"};
	JComboBox sortdirComboBox = new JComboBox(dir);	
	JComboBox sortfirstComboBox = new JComboBox(fdir);
	JComboBox sortsecComboBox = new JComboBox(sdir);
	JLabel actionItemLabel5 = new JLabel();
	JLabel actionItemLabel6 = new JLabel();
	JLabel actionItemLabel7 = new JLabel();
	JLabel actionItemLabel3 = new JLabel();
	DefaultListModel<String> l1 = new DefaultListModel<>();  
	private SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
	JList<String> list = new JList<>(l1); 
	public static final String[] ifact = {"None", "Open Action Items", "Closed Action Items"};
	JComboBox inclusionComboBox = new JComboBox(ifact);	
	JLabel inclusionLabel = new JLabel();
	
	
	//---------------------------------------------------------------------------------------------------------------------

	/**
	 * The ConsoleScreen class constructor.
	 * @throws IOException 
	 * 
	 */
	public ConsoleScreen()  {
		// Set up all of the Graphical User Interface elements and position them on the screen
		
		guiInit();
		try {
			loadScreen();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	/**
	 * Initialize each graphic element, position it on the screen, and add it to the layout.
	 * 
	 */
	private void guiInit() {
		this.setLayout(null);
		consoleLabel.setFont(new java.awt.Font("Dialog", Font.BOLD, 14));
		consoleLabel.setBorder(BorderFactory.createEtchedBorder());
		consoleLabel.setHorizontalAlignment(SwingConstants.CENTER);
		consoleLabel.setText("Console");
		consoleLabel.setBounds(new Rectangle(0, 0, 657, 20));

		copyrightLabel.setFont(new java.awt.Font("Dialog", Font.BOLD, 10));
		copyrightLabel.setHorizontalAlignment(SwingConstants.RIGHT);
		copyrightLabel.setText("Copyright � Garima Gautam");
		copyrightLabel.setBounds(new Rectangle(0, 418, 638, 15));
		
		selectedLabel.setFont(new java.awt.Font("Dialog", Font.BOLD, 11));
		selectedLabel.setText("Selected Action Item:");
		selectedLabel.setBounds(new Rectangle(6, 170, 123, 15));
		nameLabel.setFont(new java.awt.Font("Dialog", Font.BOLD, 11));
		nameLabel.setText("Name:");
		nameLabel.setBounds(new Rectangle(7, 190, 42, 15));
		nameTextField.setText("");
		nameTextField.setBounds(new Rectangle(46, 190, 390, 22));

		descriptionLabel.setFont(new java.awt.Font("Dialog", Font.BOLD, 11));
		descriptionLabel.setText("Description:");
		descriptionLabel.setBounds(new Rectangle(6, 215, 69, 15));
		descriptionScrollPane.setBounds(new Rectangle(7, 235, 430, 75));
		descriptionScrollPane.getViewport().add(descriptionTextArea);
		descriptionTextArea.setText("");

		resolutionLabel.setFont(new java.awt.Font("Dialog", Font.BOLD, 11));
		resolutionLabel.setText("Resolution:");
		resolutionLabel.setBounds(new Rectangle(6, 320, 73, 15));
		resolutionScrollPane.setBounds(new Rectangle(7, 340, 430, 75));
		resolutionScrollPane.getViewport().add(resolutionTextArea);
		resolutionTextArea.setToolTipText("");
		resolutionTextArea.setText("");

		datesLabel.setFont(new java.awt.Font("Dialog", Font.BOLD, 11));
		datesLabel.setText("Dates");
		datesLabel.setBounds(new Rectangle(450, 200, 34, 16));
		
		memLabel.setFont(new java.awt.Font("Dialog", Font.BOLD, 11));
		memLabel.setText("Assigned to Member:");
		memLabel.setBounds(new Rectangle(450, 310, 127, 15));

		creationLabel.setFont(new java.awt.Font("Dialog", Font.BOLD, 11));
		creationLabel.setText("Creation:");
		creationLabel.setHorizontalAlignment(SwingConstants.RIGHT);
		creationLabel.setBounds(new Rectangle(469, 220, 51, 16));
		creationValueLabel.setText("");
		creationValueLabel.setBounds(new Rectangle(528, 220, 85, 16));

		dueDateLabel.setFont(new java.awt.Font("Dialog", Font.BOLD, 11));
		dueDateLabel.setText("Due:");
		dueDateLabel.setHorizontalAlignment(SwingConstants.RIGHT);
		dueDateLabel.setBounds(new Rectangle(469, 242, 51, 16));

		actionItemLabel2.setFont(new java.awt.Font("Dialog", Font.BOLD, 11));
		actionItemLabel2.setText("Action Item");
		actionItemLabel2.setBounds(new Rectangle(450, 270, 67, 15));

		statusLabel.setFont(new java.awt.Font("Dialog", Font.BOLD, 11));
		statusLabel.setText("Status:");
		statusLabel.setHorizontalAlignment(SwingConstants.RIGHT);
		statusLabel.setBounds(new Rectangle(469, 287, 51, 16));
		statusValueLabel.setText("");
		statusValueLabel.setBounds(new Rectangle(528, 287, 85, 16));
		
		memValueLabel.setText("");
		memValueLabel.setBounds(new Rectangle(508, 327, 285, 16));
		
		teamValueLabel.setText("");
		teamValueLabel.setBounds(new Rectangle(508, 360, 285, 16));
        
        list.setBounds(10,50, 450,115);  
        list.addListSelectionListener(new ListSelectionListener() {

			@Override
			public void valueChanged(ListSelectionEvent event) {
				
				JList jlist = (JList) event.getSource();
				Object item = jlist.getSelectedValue();
				if(jlist.getSelectedIndices().length>0) {
				String st = item.toString();
				String[] str = st.split(" ");
				String value = "";
				for(int i =0; i<str.length; i++) {
					if(str[i].contains(":")) {
						continue;
					}
					value = value+str[i];
				}
				
				BufferedReader input;
				try {
					input = new BufferedReader(new FileReader("combo.txt"));
					
				if(list.getSelectedValue() != null){
					try {		
						  String line = "";
						  while (( line = input.readLine()) != null){
							  if(line.contains(value)){
								  
								  String[] namesList = line.split(",");
								    list.setSelectedValue(namesList[0], true);
									nameTextField.setText(namesList[0]);
									descriptionTextArea.setText(namesList[1]);
									resolutionTextArea.setText(namesList[2]);
									statusValueLabel.setText(namesList[3]);
									creationValueLabel.setText(namesList[4]);
									dueDateTextField.setText(namesList[5]);
									memValueLabel.setText(namesList[6]);
									teamValueLabel.setText(namesList[7]);
							  }
						  }
						}

						catch (IOException e) {
						    System.err.println("Error, file " + "combo.txt" + " didn't exist.");
						}
						finally {
						    try { 
								input.close();
							} catch (IOException e) {
								e.printStackTrace();
							}
						}
					}
				}
				catch (FileNotFoundException e1) {
					e1.printStackTrace();
				}
				
			}
		}
        	
        });
        
        dueDateTextField.setBounds(new Rectangle(524, 240, 90, 20));
		
        actionItemLabel3.setFont(new java.awt.Font("Dialog", Font.BOLD, 11));
		actionItemLabel3.setText("Action Items:");
		actionItemLabel3.setBounds(new Rectangle(10, 30, 80, 15));
		
		memLabel.setFont(new java.awt.Font("Dialog", Font.BOLD, 11));
		memLabel.setText("Assigned to Member:");
		memLabel.setBounds(new Rectangle(450, 310, 127, 15));
	
		teamLabel.setFont(new java.awt.Font("Dialog", Font.BOLD, 11));
		teamLabel.setText("Assigned to Team:");
		teamLabel.setBounds(new Rectangle(450, 345, 127, 15));
		
		inclusionLabel.setFont(new java.awt.Font("Dialog", Font.BOLD, 11));
		inclusionLabel.setText("Inclusion Factor:");
		inclusionLabel.setBounds(new Rectangle(478, 140, 280, 15));
		inclusionComboBox.setBounds(new Rectangle(478, 155, 140, 25));
		inclusionComboBox.addItemListener(new ItemListener() {
			@Override
			public void itemStateChanged(ItemEvent event) {
				JComboBox inclusionComboBox = (JComboBox) event.getSource();
				Object item = event.getItem();
				int total = 0;
				BufferedReader input;
				try {
					input = new BufferedReader(new FileReader("combo.txt"));
				
				if(item.toString()==ifact[1]) {
					
					ArrayList<String> strings = new ArrayList<String>();
					
					try {
						
					  String line = null;
					  while (( line = input.readLine()) != null){
						  if(line.contains("Open")) {
						  String[] itemList = line.split(",");
						  strings.add(itemList[0]);
						  total++;
						  }
					  }
					 
					}

					catch (IOException e) {
					    System.err.println("Error, file " + "combo.txt" + " didn't exist.");
					}
					finally {
					    try {
							input.close();
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
					
					l1.removeAllElements();
					
					String[] lineArray = strings.toArray(new String[]{});
					for(int i=0; i<lineArray.length; i++) {
						l1.addElement(lineArray[i]);
					}
				}
				
				else if(item.toString()==ifact[2]) {
					
					ArrayList<String> strings = new ArrayList<String>();
					
					try {
						
					  String line = null;
					  while (( line = input.readLine()) != null){
						  if(line.contains("Closed")) {
						  String[] itemList = line.split(",");
						  strings.add(itemList[0]);
						  total++;
						  }
					  }
					 
					}

					catch (IOException e) {
					    System.err.println("Error, file " + "combo.txt" + " didn't exist.");
					}
					finally {
					    try {
							input.close();
						} catch (IOException e) {
							e.printStackTrace();
						}
					}
					
					l1.removeAllElements();
					
					String[] lineArray = strings.toArray(new String[]{});
					for(int i=0; i<lineArray.length; i++) {
						l1.addElement(lineArray[i]);
					}
				}
				
				} catch (FileNotFoundException e1) {
					e1.printStackTrace();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}	
		});
        
        sortdirComboBox.setBounds(new Rectangle(478, 35, 140, 25));
        sortdirComboBox.addItemListener(new ItemListener() {
			@Override
			public void itemStateChanged(ItemEvent event) {
				event.getSource();
				Object item = event.getItem();
				if(item.toString()==dir[0]) {
					BufferedReader input;
					try {
						input = new BufferedReader(new FileReader("combo.txt"));
					
					ArrayList<String> strings = new ArrayList<String>();
					ArrayList<String> strings1 = new ArrayList<String>();
						
					  String line = null;
					  
						while (( line = input.readLine()) != null){
							  String[] itemList = line.split(",");
							  strings.add(itemList[0]);
							  strings1.add(itemList[0]);
						  }
						
						Collections.sort(strings);
						
						l1.removeAllElements();
						
						String[] lineArray1 = strings.toArray(new String[]{});
						String[] lineArray2 = strings1.toArray(new String[]{});
						for(int i=0; i<lineArray1.length; i++) {
							l1.addElement(lineArray1[i]);
						}
						list.setSelectedValue(lineArray2[strings1.size()-1], true);
						input.close();
					} catch (IOException e) {
						e.printStackTrace();
					}
					
				} 
				if(item.toString()==dir[1]) {
					BufferedReader input;
					try {
						input = new BufferedReader(new FileReader("combo.txt"));
					
					ArrayList<String> strings = new ArrayList<String>();
					ArrayList<String> strings1 = new ArrayList<String>();
					  String line = null;
					  
						while (( line = input.readLine()) != null){
							  String[] itemList = line.split(",");
							  strings.add(itemList[0]);
							  strings1.add(itemList[0]);
						  }
						
						Collections.sort(strings, Collections.reverseOrder());
						
						l1.removeAllElements();
						
						String[] lineArray1 = strings.toArray(new String[]{});
						String[] lineArray2 = strings1.toArray(new String[]{});
						for(int i=0; i<lineArray1.length; i++) {
							l1.addElement(lineArray1[i]);
						}
						
						list.setSelectedValue(lineArray2[strings1.size()-1], true);
						input.close();
					} catch (IOException e) {
						e.printStackTrace();
					}
				}
				
			}
		});
        
        sortfirstComboBox.setBounds(new Rectangle(478, 75, 140, 25));
        sortfirstComboBox.addItemListener(new ItemListener() {
			@Override
			public void itemStateChanged(ItemEvent event) {
				event.getSource();
				Object item = event.getItem();
				if(item.toString()==fdir[3]) {
					int total = 0;
					BufferedReader input;
					try {
						input = new BufferedReader(new FileReader("combo.txt"));
						ArrayList<String> strings = new ArrayList<String>();
						String line = null;
						while (( line = input.readLine()) != null){
							  String[] itemList = line.split(",");
							  strings.add(itemList[6]+": "+itemList[0]);
							  total++;
						  }
						
						if(sortdirComboBox.getSelectedIndex()==0) {
							Collections.sort(strings);
						} else if(sortdirComboBox.getSelectedIndex()==1) {
							Collections.sort(strings, Collections.reverseOrder());
						}
						
						l1.removeAllElements();
						
						String[] lineArray1 = strings.toArray(new String[]{});
						for(int i=0; i<lineArray1.length; i++) {
							l1.addElement(lineArray1[i]);
						}
						input.close();
					} catch (IOException e) {
						e.printStackTrace();
					}
				}
				else if(item.toString()==fdir[0]) {
					list.setSelectedIndex(-1);
					int total = 0;
					BufferedReader input;
					try {
						input = new BufferedReader(new FileReader("combo.txt"));
					
					ArrayList<String> strings = new ArrayList<String>();
					ArrayList<String> strings1 = new ArrayList<String>();
						
					  String line = null;
						while (( line = input.readLine()) != null){
							  String[] itemList = line.split(",");
							  strings.add(itemList[0]);
							  strings1.add(itemList[0]);
							  total++;
						  }
						
						if(sortdirComboBox.getSelectedIndex()==0) {
							Collections.sort(strings);
						} else if(sortdirComboBox.getSelectedIndex()==1) {
							Collections.sort(strings, Collections.reverseOrder());
						}
						
						l1.removeAllElements();
						
						String[] lineArray1 = strings.toArray(new String[]{});
						String[] lineArray2 = strings1.toArray(new String[]{});
						for(int i=0; i<lineArray1.length; i++) {
							l1.addElement(lineArray1[i]);
						}
						
						list.setSelectedValue(lineArray2[strings1.size()-1],true);
						//System.out.println(lineArray2[strings1.size()-1]);
						input.close();
					} catch (IOException e) {
						e.printStackTrace();
					}
				}
				else if(item.toString()==fdir[1]) {
					int total = 0;
					BufferedReader input;
					try {
						input = new BufferedReader(new FileReader("combo.txt"));
					
					ArrayList<String> strings = new ArrayList<String>();
					ArrayList<String> strings1 = new ArrayList<String>();
						
					  String line = null;
						while (( line = input.readLine()) != null){
							  String[] itemList = line.split(",");
							  strings.add(itemList[5]+": "+itemList[0]);
							  strings1.add(itemList[0]);
							  total++;
						  }
						
						if(sortdirComboBox.getSelectedIndex()==0) {
							Collections.sort(strings);
						} else if(sortdirComboBox.getSelectedIndex()==1) {
							Collections.sort(strings, Collections.reverseOrder());
						}
						
						l1.removeAllElements();
						
						String[] lineArray1 = strings.toArray(new String[]{});
						String[] lineArray2 = strings1.toArray(new String[]{});
						for(int i=0; i<lineArray1.length; i++) {
							l1.addElement(lineArray1[i]);
						}
						
						//actionComboBox.setSelectedItem(lineArray2[strings1.size()-1]);
						//System.out.println(lineArray2[strings1.size()-1]);
						input.close();
					} catch (IOException e) {
						e.printStackTrace();
					}
					
				} 
				
				else if(item.toString()==fdir[4]) {
					int total = 0;
					BufferedReader input;
					try {
						input = new BufferedReader(new FileReader("combo.txt"));
						ArrayList<String> strings = new ArrayList<String>();
						String line = null;
						while (( line = input.readLine()) != null){
							  String[] itemList = line.split(",");
							  strings.add(itemList[7]+": "+itemList[0]);
							  total++;
						  }
						
						if(sortdirComboBox.getSelectedIndex()==0) {
							Collections.sort(strings);
						} else if(sortdirComboBox.getSelectedIndex()==1) {
							Collections.sort(strings, Collections.reverseOrder());
						}
						
						l1.removeAllElements();
						
						String[] lineArray1 = strings.toArray(new String[]{});
						for(int i=0; i<lineArray1.length; i++) {
							l1.addElement(lineArray1[i]);
						}
						input.close();
					} catch (IOException e) {
						e.printStackTrace();
					}
				}
			
				else if(item.toString()==fdir[2]) {
					int total = 0;
					BufferedReader input;
					try {
						input = new BufferedReader(new FileReader("combo.txt"));
					
					ArrayList<String> strings = new ArrayList<String>();
					ArrayList<String> strings1 = new ArrayList<String>();
						
					  String line = null;
						while (( line = input.readLine()) != null){
							  String[] itemList = line.split(",");
							  strings.add(itemList[4]+": "+itemList[0]);
							  strings1.add(itemList[0]);
							  total++;
						  }
						
						if(sortdirComboBox.getSelectedIndex()==0) {
							Collections.sort(strings);
						} else if(sortdirComboBox.getSelectedIndex()==1) {
							Collections.sort(strings, Collections.reverseOrder());
						}
						
						l1.removeAllElements();
						
						String[] lineArray1 = strings.toArray(new String[]{});
						String[] lineArray2 = strings1.toArray(new String[]{});
						for(int i=0; i<lineArray1.length; i++) {
							l1.addElement(lineArray1[i]);
						}
						
						//actionComboBox.setSelectedItem(lineArray2[strings1.size()-1]);
						//System.out.println(lineArray2[strings1.size()-1]);
						input.close();
					} catch (IOException e) {
						e.printStackTrace();
					}
					
				}
			}	
		});
        
        sortsecComboBox.setBounds(new Rectangle(478, 115, 140, 25));
        sortsecComboBox.addItemListener(new ItemListener() {
			@Override
			public void itemStateChanged(ItemEvent event) {
				event.getSource();
				Object item = event.getItem();
				if(item.toString()==sdir[1]) {
					int total = 0;
					BufferedReader input;
					try {
						input = new BufferedReader(new FileReader("combo.txt"));
					
					ArrayList<String> strings = new ArrayList<String>();
					ArrayList<String> strings1 = new ArrayList<String>();
						
					  String line = null;
						while (( line = input.readLine()) != null){
							  String[] itemList = line.split(",");
							  if(sortfirstComboBox.getSelectedIndex()==1) {
								  strings.add(itemList[5]+": "+itemList[5]+": "+itemList[0]);
							  }else if(sortfirstComboBox.getSelectedIndex()==2){
								  strings.add(itemList[4]+": "+itemList[5]+": "+itemList[0]);
							  }else if(sortfirstComboBox.getSelectedIndex()==3){
								  strings.add(itemList[6]+": "+itemList[5]+": "+itemList[0]);
							  }else if(sortfirstComboBox.getSelectedIndex()==4){
								  strings.add(itemList[7]+": "+itemList[5]+": "+itemList[0]);
							  }
							  strings1.add(itemList[0]);
							  total++;
						  }
						
						if(sortdirComboBox.getSelectedIndex()==0) {
							Collections.sort(strings);
						} else if(sortdirComboBox.getSelectedIndex()==1) {
							Collections.sort(strings, Collections.reverseOrder());
						}
						
						l1.removeAllElements();
						
						String[] lineArray1 = strings.toArray(new String[]{});
						String[] lineArray2 = strings1.toArray(new String[]{});
						for(int i=0; i<lineArray1.length; i++) {
							l1.addElement(lineArray1[i]);
						}
						
						list.setSelectedValue(lineArray2[strings1.size()-1], true);
						//System.out.println(lineArray2[strings1.size()-1]);
						input.close();
					} catch (IOException e) {
						e.printStackTrace();
					}
					
				} 
				
				else if(item.toString()==sdir[2]) {
					int total = 0;
					BufferedReader input;
					try {
						input = new BufferedReader(new FileReader("combo.txt"));
					
					ArrayList<String> strings = new ArrayList<String>();
					ArrayList<String> strings1 = new ArrayList<String>();
						
					  String line = null;
						while (( line = input.readLine()) != null){
							  String[] itemList = line.split(",");
							  if(sortfirstComboBox.getSelectedIndex()==1) {
								  strings.add(itemList[5]+": "+itemList[4]+": "+itemList[0]);
							  }else if(sortfirstComboBox.getSelectedIndex()==2){
								  strings.add(itemList[4]+": "+itemList[4]+": "+itemList[0]);
							  }else if(sortfirstComboBox.getSelectedIndex()==3){
								  strings.add(itemList[6]+": "+itemList[4]+": "+itemList[0]);
							  }else if(sortfirstComboBox.getSelectedIndex()==4){
								  strings.add(itemList[7]+": "+itemList[4]+": "+itemList[0]);
							  }
							  strings1.add(itemList[0]);
							  total++;
						  }
						
						if(sortdirComboBox.getSelectedIndex()==0) {
							Collections.sort(strings);
						} else if(sortdirComboBox.getSelectedIndex()==1) {
							Collections.sort(strings, Collections.reverseOrder());
						}
						
						l1.removeAllElements();
						
						String[] lineArray1 = strings.toArray(new String[]{});
						String[] lineArray2 = strings1.toArray(new String[]{});
						for(int i=0; i<lineArray1.length; i++) {
							l1.addElement(lineArray1[i]);
						}
						
						list.setSelectedValue(lineArray2[strings1.size()-1], true);
						//System.out.println(lineArray2[strings1.size()-1]);
						input.close();
					} catch (IOException e) {
						e.printStackTrace();
					}
					
				}
				
				else if(item.toString()==sdir[3]) {
					int total = 0;
					BufferedReader input;
					try {
						input = new BufferedReader(new FileReader("combo.txt"));
					
					ArrayList<String> strings = new ArrayList<String>();
					ArrayList<String> strings1 = new ArrayList<String>();
						
					  String line = null;
						while (( line = input.readLine()) != null){
							  String[] itemList = line.split(",");
							  if(sortfirstComboBox.getSelectedIndex()==1) {
								  strings.add(itemList[5]+": "+itemList[6]+": "+itemList[0]);
							  }else if(sortfirstComboBox.getSelectedIndex()==2){
								  strings.add(itemList[4]+": "+itemList[6]+": "+itemList[0]);
							  }else if(sortfirstComboBox.getSelectedIndex()==3){
								  strings.add(itemList[6]+": "+itemList[6]+": "+itemList[0]);
							  }else if(sortfirstComboBox.getSelectedIndex()==4){
								  strings.add(itemList[7]+": "+itemList[6]+": "+itemList[0]);
							  }
							  strings1.add(itemList[0]);
							  total++;
						  }
						
						if(sortdirComboBox.getSelectedIndex()==0) {
							Collections.sort(strings);
						} else if(sortdirComboBox.getSelectedIndex()==1) {
							Collections.sort(strings, Collections.reverseOrder());
						}
						
						l1.removeAllElements();
						
						String[] lineArray1 = strings.toArray(new String[]{});
						String[] lineArray2 = strings1.toArray(new String[]{});
						for(int i=0; i<lineArray1.length; i++) {
							l1.addElement(lineArray1[i]);
						}
						
						list.setSelectedValue(lineArray2[strings1.size()-1], true);
						//System.out.println(lineArray2[strings1.size()-1]);
						input.close();
					} catch (IOException e) {
						e.printStackTrace();
					}
					
				}
				
				else if(item.toString()==sdir[4]) {
					int total = 0;
					BufferedReader input;
					try {
						input = new BufferedReader(new FileReader("combo.txt"));
					
					ArrayList<String> strings = new ArrayList<String>();
					ArrayList<String> strings1 = new ArrayList<String>();
						
					  String line = null;
						while (( line = input.readLine()) != null){
							  String[] itemList = line.split(",");
							  if(sortfirstComboBox.getSelectedIndex()==1) {
								  strings.add(itemList[5]+": "+itemList[7]+": "+itemList[0]);
							  }else if(sortfirstComboBox.getSelectedIndex()==2){
								  strings.add(itemList[4]+": "+itemList[7]+": "+itemList[0]);
							  }else if(sortfirstComboBox.getSelectedIndex()==3){
								  strings.add(itemList[6]+": "+itemList[7]+": "+itemList[0]);
							  }else if(sortfirstComboBox.getSelectedIndex()==4){
								  strings.add(itemList[7]+": "+itemList[7]+": "+itemList[0]);
							  }
							  strings1.add(itemList[0]);
							  total++;
						  }
						
						if(sortdirComboBox.getSelectedIndex()==0) {
							Collections.sort(strings);
						} else if(sortdirComboBox.getSelectedIndex()==1) {
							Collections.sort(strings, Collections.reverseOrder());
						}
						
						l1.removeAllElements();
						
						String[] lineArray1 = strings.toArray(new String[]{});
						String[] lineArray2 = strings1.toArray(new String[]{});
						for(int i=0; i<lineArray1.length; i++) {
							l1.addElement(lineArray1[i]);
						}
						
						//actionComboBox.setSelectedItem(lineArray2[strings1.size()-1]);
						//System.out.println(lineArray2[strings1.size()-1]);
						input.close();
					} catch (IOException e) {
						e.printStackTrace();
					}
					
				}
				
				else if(item.toString()==sdir[0]) {
					list.setSelectedIndex(-1);
					BufferedReader input;
					try {
						input = new BufferedReader(new FileReader("combo.txt"));
					
					ArrayList<String> strings = new ArrayList<String>();
					ArrayList<String> strings1 = new ArrayList<String>();
						
					  String line = null;
						while (( line = input.readLine()) != null){
							  String[] itemList = line.split(",");
							  if(sortfirstComboBox.getSelectedIndex()==1) {
								  strings.add(itemList[5]+": "+itemList[0]);
							  }else if(sortfirstComboBox.getSelectedIndex()==2){
								  strings.add(itemList[4]+": "+itemList[0]);
							  }else if(sortfirstComboBox.getSelectedIndex()==3){
								  strings.add(itemList[6]+": "+itemList[0]);
							  }else if(sortfirstComboBox.getSelectedIndex()==0){
								  strings.add(itemList[0]);
							  }
							  strings1.add(itemList[0]);
						  }
						
						if(sortdirComboBox.getSelectedIndex()==0) {
							Collections.sort(strings);
						} else if(sortdirComboBox.getSelectedIndex()==1) {
							Collections.sort(strings, Collections.reverseOrder());
						}
						
						l1.removeAllElements();
						
						String[] lineArray1 = strings.toArray(new String[]{});
						String[] lineArray2 = strings1.toArray(new String[]{});
						for(int i=0; i<lineArray1.length; i++) {
							l1.addElement(lineArray1[i]);
						}
						
						list.setSelectedValue(lineArray2[strings1.size()-1], true);
						//System.out.println(lineArray2[strings1.size()-1]);
						input.close();
					} catch (IOException e) {
						e.printStackTrace();
					}
				}
			}	
		});
        
        actionItemLabel5.setFont(new java.awt.Font("Dialog", Font.BOLD, 11));
		actionItemLabel5.setText("Sorting Direction:");
		actionItemLabel5.setBounds(new Rectangle(478, 20, 280, 15));
		
		actionItemLabel6.setFont(new java.awt.Font("Dialog", Font.BOLD, 11));
		actionItemLabel6.setText("First Sorting Factor:");
		actionItemLabel6.setBounds(new Rectangle(478, 60, 280, 15));
		
		actionItemLabel7.setFont(new java.awt.Font("Dialog", Font.BOLD, 11));
		actionItemLabel7.setText("Second Sorting Factor:");
		actionItemLabel7.setBounds(new Rectangle(478, 100, 280, 15));
        
        this.add(list);  
		this.add(consoleLabel);
		this.add(copyrightLabel);
		// Add the objects to the layout
		this.add(selectedLabel);
		this.add(nameLabel);
		this.add(nameTextField);
		this.add(descriptionLabel);
		this.add(descriptionScrollPane);
		this.add(resolutionLabel);
		this.add(resolutionScrollPane);

		this.add(datesLabel);
		this.add(teamLabel);
		this.add(creationLabel);
		this.add(creationValueLabel);
		this.add(statusValueLabel);
		this.add(dueDateLabel);
		this.add(actionItemLabel2);
		this.add(statusLabel);
		this.add(dueDateTextField);
		this.add(memLabel);
		this.add(memValueLabel);
		this.add(teamValueLabel);		
		
		this.add(sortdirComboBox);
		this.add(sortfirstComboBox);
		this.add(sortsecComboBox);
		
		this.add(actionItemLabel3);
		this.add(actionItemLabel5);
		this.add(actionItemLabel6);
		this.add(actionItemLabel7);
		this.add(inclusionComboBox);
		this.add(inclusionLabel);

	}
	
	/**
	 * Fill the screen with the values of the current action item, if we have one, and display it.
	 * @throws IOException 
	 */
	public void loadScreen() throws IOException {
		sortdirComboBox.setSelectedIndex(-1);
		sortfirstComboBox.setSelectedIndex(-1);
		sortsecComboBox.setSelectedIndex(-1);
		
		try {
		      File myObj = new File("combo.txt");
		      if (myObj.createNewFile()) {
		        System.out.println("File created: " + myObj.getName());
		      } else {
		        System.out.println("File already exists.");
		      }
		    } catch (IOException e) {
		      System.out.println("An error occurred.");
		      e.printStackTrace();
		    }
		int total = 0;
		BufferedReader input = new BufferedReader(new FileReader("combo.txt"));
		ArrayList<String> strings = new ArrayList<String>();
		try {
			
		  String line = null;
		  while (( line = input.readLine()) != null){
			  String[] itemList = line.split(",");
			  strings.add(itemList[0]);
			  total++;
		  }
		}

		catch (FileNotFoundException e) {
		    System.err.println("Error, file " + "combo.txt" + " didn't exist.");
		}
		finally {
		    input.close();
		}
		
		l1.removeAllElements();
		
		String[] lineArray = strings.toArray(new String[]{});
		for(int i=0; i<lineArray.length; i++) {
			l1.addElement(lineArray[i]);  
		}
		String linepos ="";
		if(total>0) {
		linepos = Files.readAllLines(Paths.get("combo.txt")).get(total-1);
		//System.out.print(linepos);
		String[] namesList = linepos.split(",");
		//actionComboBox.setSelectedItem(namesList[0]);
		list.setSelectedValue(namesList[0], true);
		nameTextField.setText(namesList[0]);
		descriptionTextArea.setText(namesList[1]);
		resolutionTextArea.setText(namesList[2]);
		statusValueLabel.setText(namesList[3]);
		creationValueLabel.setText(namesList[4]);
		dueDateTextField.setText(namesList[5]);
		
		}
	}
}
