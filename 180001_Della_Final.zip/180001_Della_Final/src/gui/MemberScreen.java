package gui;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Collections;

import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

import model.ActionItem;
import model.ActionItemManager;

/**
 * <p>
 * Title: MemberScreen
 * </p>
 *
 * <p>
 * Description: The Della Member Screen code
 * </p>
 *
 * <p>
 * Copyright: Copyright � 2007
 * </p>
 *
 * @author Lynn Robert Carter
 * @version 1.00
 * Many thanks to Harry Sameshima for his original work.
 * @version Della00
 * @co-author Garima Gautam
 * Date- Jan 16, 2021
 * Role- Analyzed the code and created an XML file. 
 * @version Della10
 * @co-author Garima Gautam
 * Date- Feb 07, 2021
 * Role- Completed the user interface of all tabs and functionality of each element
 * used in the gui(update, create, clear, delete, add, remove, sorting etc.)  
*/
public class MemberScreen extends JPanel {
	//---------------------------------------------------------------------------------------------------------------------
	// Member Screen constants


	//---------------------------------------------------------------------------------------------------------------------
	// Member Screen attributes


	//---------------------------------------------------------------------------------------------------------------------
	// Member Screen GUI elements
	JLabel memberLabel = new JLabel();
	JLabel instLabel = new JLabel();
	JLabel ateamLabel = new JLabel();
	JLabel rteamLabel = new JLabel();
	JLabel availLabel = new JLabel();
	JLabel currLabel = new JLabel();
	JLabel availValueLabel = new JLabel();
	JLabel currValueLabel = new JLabel();
	JLabel name = new JLabel();
	JLabel individuals = new JLabel();
	JLabel addLabel = new JLabel();
	JLabel removeLabel = new JLabel();
	JTextField nameTextField = new JTextField();
	JButton addButton = new JButton();
	
	ActionListener addButtonActionListner = new ActionListener() {
		public void actionPerformed(ActionEvent ae) { 
			try {
				addMembers(ae);
			} catch (IOException e) {
				e.printStackTrace();
			}
			}
	};
	
	JButton addfButton = new JButton();
	
	ActionListener addfButtonActionListner = new ActionListener() {
		public void actionPerformed(ActionEvent ae) { 
			try {
				addfMembers(ae);
			} catch (IOException e) {
				e.printStackTrace();
			}
			}
	};
	
	JButton removeButton = new JButton();
	ActionListener removeButtonActionListner = new ActionListener() {
		public void actionPerformed(ActionEvent ae) { 
			try {
				removeMembers(ae);
			} catch (IOException e) {
				e.printStackTrace();
			}
			}
	};
	
	JButton removefButton = new JButton();
	ActionListener removefButtonActionListner = new ActionListener() {
		public void actionPerformed(ActionEvent ae) { 
			try {
				removefMembers(ae);
			} catch (IOException e) {
				e.printStackTrace();
			}
			}
	};
	
	DefaultListModel<String> l1 = new DefaultListModel<>(); 
	JList<String> list = new JList<>(l1);  
	DefaultListModel<String> l2 = new DefaultListModel<>(); 
	JList<String> list2 = new JList<>(l2); 
	DefaultListModel<String> l3 = new DefaultListModel<>(); 
	JList<String> list3 = new JList<>(l3);  
	String add = "<html>To add a name to the list:<br>"+
			"1. Click on the box above<br>"+
			"2. Type the name<br>"+
			"3. Click the add to list button</html>";
	String remove = "<html>To remove a name from the list:<br>"+
			"1. Click on the name to remove<br>"+
			"2. Click on remove from list button</html>";
	String ateam = "<html>To add a team affiliation for an individual:<br>"+
			"1. Click on the name of the individual above right.<br>"+
			"2. Click on the team name in the list below.<br>"+
			"3. Click on Add affiliation button.";
	String rteam = "<html>To remove a team affiliation for an individual:<br>"+
			"1. Click on the name of the individual above.<br>"+
			"2. Click on the team name in the list below.<br>"+
			"3. Click on Remove affiliation button.";

	//---------------------------------------------------------------------------------------------------------------------

	/**
	 * The MemberScreen class constructor.
	 * 
	 */
	public MemberScreen() {
		// Set up all of the Graphical User Interface elements and place them on the screen
		guiInit();
		try {
			loadScreen();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	/**
	 * Initialize each graphic element, position it on the screen, and add it to the layout.
	 * 
	 */
	private void guiInit() {
		this.setLayout(null);
		memberLabel.setFont(new java.awt.Font("Dialog", Font.BOLD, 14));
		memberLabel.setBorder(BorderFactory.createEtchedBorder());
		memberLabel.setHorizontalAlignment(SwingConstants.CENTER);
		memberLabel.setText("Members");
		memberLabel.setBounds(new Rectangle(0, 0, 657, 20));
		
		name.setFont(new java.awt.Font("Dialog", Font.BOLD, 11));
		name.setText("Name of someone new (Last, first, middle)");
		name.setBounds(new Rectangle(6, 40, 300, 15));
		
		individuals.setFont(new java.awt.Font("Dialog", Font.BOLD, 11));
		individuals.setText("Individuals known by Della");
		individuals.setBounds(new Rectangle(420, 40, 300, 15));
		
		addLabel.setFont(new java.awt.Font("Dialog", Font.BOLD, 11));
		addLabel.setText(add);
		addLabel.setBounds(new Rectangle(6, 60, 500, 150));
		
		removeLabel.setFont(new java.awt.Font("Dialog", Font.BOLD, 11));
		removeLabel.setText(remove);
		removeLabel.setBounds(new Rectangle(6, 125, 500, 150));
		
		nameTextField.setText("");
		nameTextField.setBounds(new Rectangle(6, 60, 190, 22));
		
		addButton.setFont(new Font("Dialog", Font.BOLD, 11));
		addButton.setBounds(new Rectangle(220, 60, 170, 30));
		addButton.setText("Add to List -->");
		addButton.addActionListener(addButtonActionListner);

		removeButton.setFont(new Font("Dialog", Font.BOLD, 11));
		removeButton.setBounds(new Rectangle(220, 120, 170, 30));
		removeButton.setText("<-- Remove from List");
		removeButton.addActionListener(removeButtonActionListner);
		
		addfButton.setFont(new Font("Dialog", Font.BOLD, 11));
		addfButton.setBounds(new Rectangle(225, 330, 170, 30));
		addfButton.setText("Add affiliation -->");
		addfButton.addActionListener(addfButtonActionListner);

		removefButton.setFont(new Font("Dialog", Font.BOLD, 11));
		removefButton.setBounds(new Rectangle(225, 390, 170, 30));
		removefButton.setText("<-- Remove affiliation");
		removefButton.addActionListener(removefButtonActionListner);
		
		instLabel.setFont(new java.awt.Font("Dialog", Font.BOLD, 11));
		instLabel.setText("<html>Click on an individuals's name</br> to see team affiliations.</html>");
		instLabel.setBounds(new Rectangle(220, 160, 170, 30));
		
		ateamLabel.setFont(new java.awt.Font("Dialog", Font.BOLD, 11));
		ateamLabel.setText(ateam);
		ateamLabel.setBounds(new Rectangle(6, 185, 500, 150));
		
		rteamLabel.setFont(new java.awt.Font("Dialog", Font.BOLD, 11));
		rteamLabel.setText(rteam);
		rteamLabel.setBounds(new Rectangle(390, 185, 500, 150));
		
		availLabel.setFont(new java.awt.Font("Dialog", Font.BOLD, 11));
		availLabel.setText("Available teams for");
		availLabel.setBounds(new Rectangle(6, 225, 500, 150));
		
		availValueLabel.setFont(new java.awt.Font("Dialog", Font.BOLD, 11));
		availValueLabel.setText("");
		availValueLabel.setBounds(new Rectangle(6, 240, 500, 150));
		
		currLabel.setFont(new java.awt.Font("Dialog", Font.BOLD, 11));
		currLabel.setText("Current teams for");
		currLabel.setBounds(new Rectangle(390, 225, 500, 150));
		
		currValueLabel.setFont(new java.awt.Font("Dialog", Font.BOLD, 11));
		currValueLabel.setText("");
		currValueLabel.setBounds(new Rectangle(390, 240, 500, 150));
		
		list.setBounds(420,60, 200,150);
		 list.addListSelectionListener(new ListSelectionListener() {

				@Override
				public void valueChanged(ListSelectionEvent event) {
					
					JList jlist = (JList) event.getSource();
					Object item = jlist.getSelectedValue();
					if(jlist.getSelectedIndices().length>0) {
						availValueLabel.setText(item.toString());
						currValueLabel.setText(item.toString());
					}
			}
	        	
	        });
		 
		list2.setBounds(20,325, 200,90);
		list3.setBounds(420,325, 200,90);
		
		//----------------------------------------------------------------------------
		// Add the objects to the layout
		this.add(memberLabel);
		this.add(removeLabel);
		this.add(addLabel);
		this.add(name);
		this.add(individuals);
		this.add(nameTextField);
		this.add(addButton);
		this.add(removeButton);
		this.add(list);
		this.add(list2);
		this.add(list3);
		this.add(instLabel);
		this.add(ateamLabel);
		this.add(rteamLabel);
		this.add(availLabel);
		this.add(currLabel);
		this.add(availValueLabel);
		this.add(currValueLabel);
		this.add(addfButton);
		this.add(removefButton);
		
	}
	
	/**
	 * Fill the screen with the values of the current action item, if we have one, and display it.
	 * @throws IOException 
	 */
	public void loadScreen() throws IOException {
		
		try {
		      File myObj = new File("members.txt");
		      File myObj1 = new File("removedMem.txt");
		      if (myObj.createNewFile()) {
		        System.out.println("File created: " + myObj.getName());
		      } 
		      if (myObj1.createNewFile()) {
			        System.out.println("File created: " + myObj1.getName());
			      } 
		      else {
		        System.out.println("Files already exists.");
		      }
		    } catch (IOException e) {
		      System.out.println("An error occurred.");
		      e.printStackTrace();
		    }
		
		int total = 0, total1 = 0;
		BufferedReader input = new BufferedReader(new FileReader("members.txt"));
		BufferedReader input1 = new BufferedReader(new FileReader("removedMem.txt"));
		ArrayList<String> strings = new ArrayList<String>();
		try {
			
		  String line = null;
		  String line1 = null;
		  while (( line = input.readLine()) != null){
			  strings.add(line);
			  total++;
		  }
		  while (( line1 = input1.readLine()) != null){
			  total1++;
		  }
		}

		catch (FileNotFoundException e) {
		    System.err.println("Error, file " + "members.txt" + " didn't exist.");
		}
		finally {
		    input.close();
		}
		Collections.sort(strings);
		l1.removeAllElements();
		
		String[] lineArray = strings.toArray(new String[]{});
		for(int i=0; i<lineArray.length; i++) {
			l1.addElement(lineArray[i]);
		}
		String linepos ="", linepos1 ="", linepos2 ="";
		if(total>0) {
			linepos = Files.readAllLines(Paths.get("members.txt")).get(total-1);
			list.setSelectedValue(linepos, true);
		
		}
		if(total1>0) {
			linepos1 = Files.readAllLines(Paths.get("removedMem.txt")).get(total1-1);
			if(list.getSelectedValue().toString()==linepos1) {
				nameTextField.setText(linepos2);
			}
			else {
				nameTextField.setText(linepos1);
			}	
		}
		
		availValueLabel.setText(list.getSelectedValue().toString());
		currValueLabel.setText(list.getSelectedValue().toString());
		
	}
	
	
	public void addMembers(ActionEvent ae) throws IOException {
		FileWriter writer = new FileWriter("members.txt", true); 
		String s = nameTextField.getText().toString() +"\n";
		System.out.println(s);
		writer.write(s);
		writer.close();
		
		l1.addElement(nameTextField.getText().toString());
		list.setSelectedValue(nameTextField.getText().toString(), true);
		
		nameTextField.setText("");
		
	}
	
	public void removeMembers(ActionEvent ae) throws IOException {
		
		int x = JOptionPane.showConfirmDialog(this,
				" \n" +
				"A member removal has been requested and there     \n" +
				"Do you want to discard these edits?\n\n" +
				"Click \"Yes\" to save these edits.\n\n" +
				"Click \"No\" to return to Console Screen.\n ",
				"Delete Member Confirmation!",
				JOptionPane.YES_NO_OPTION,
				JOptionPane.YES_NO_OPTION);
		if (x==0) {
		
		BufferedReader input = new BufferedReader(new FileReader("members.txt"));
		String line = "";
		FileWriter writer = new FileWriter("members.txt", true);
		FileWriter writer1 = new FileWriter("removedMem.txt", true);
		//String linepos = Files.readAllLines(Paths.get("combo.txt")).get(count);
		ArrayList<String> removed = new ArrayList<String>();
	    ArrayList<String> updateList = new ArrayList<String>();
	    
		  while (( line = input.readLine()) != null){
			  if(line.contains(list.getSelectedValue().toString())) {
				  removed.add(list.getSelectedValue().toString());
				  nameTextField.setText(list.getSelectedValue().toString());
				  continue;
			  }
			  updateList.add(line);
		  }
		  String[] stringArray1 = removed.toArray(new String[0]);
		  
		  for(int i = 0 ; i<stringArray1.length; i++) {
			  writer1.write(stringArray1[i]+System.lineSeparator());
		  }
		  writer1.close();
		  
		  int size = updateList.size();
		  String[] stringArray = updateList.toArray(new String[0]);
		  
		  PrintWriter pwriter = new PrintWriter("members.txt");
		  pwriter.print("");
		  pwriter.close();
		  
		  for(int i = 0 ; i < size; i++) {
			  writer.write(stringArray[i]+System.lineSeparator());
		  }
		  writer.close();
		
		l1.removeElement(list.getSelectedValue());
		}
	}
	
	public void addfMembers(ActionEvent ae) throws IOException {
		FileWriter writer = new FileWriter("members.txt", true); 
		String s = nameTextField.getText().toString() +"\n";
		System.out.println(s);
		writer.write(s);
		writer.close();
		
		l1.addElement(nameTextField.getText().toString());
		list.setSelectedValue(nameTextField.getText().toString(), true);
		
		nameTextField.setText("");
		
	}
	
	public void removefMembers(ActionEvent ae) throws IOException {
		
		int x = JOptionPane.showConfirmDialog(this,
				" \n" +
				"A member removal has been requested and there     \n" +
				"Do you want to discard these edits?\n\n" +
				"Click \"Yes\" to save these edits.\n\n" +
				"Click \"No\" to return to Console Screen.\n ",
				"Delete Member Confirmation!",
				JOptionPane.YES_NO_OPTION,
				JOptionPane.YES_NO_OPTION);
		if (x==0) {
		
		BufferedReader input = new BufferedReader(new FileReader("members.txt"));
		String line = "";
		FileWriter writer = new FileWriter("members.txt", true);
		FileWriter writer1 = new FileWriter("removedMem.txt", true);
		//String linepos = Files.readAllLines(Paths.get("combo.txt")).get(count);
		ArrayList<String> removed = new ArrayList<String>();
	    ArrayList<String> updateList = new ArrayList<String>();
	    
		  while (( line = input.readLine()) != null){
			  if(line.contains(list.getSelectedValue().toString())) {
				  removed.add(list.getSelectedValue().toString());
				  nameTextField.setText(list.getSelectedValue().toString());
				  continue;
			  }
			  updateList.add(line);
		  }
		  String[] stringArray1 = removed.toArray(new String[0]);
		  
		  for(int i = 0 ; i<stringArray1.length; i++) {
			  writer1.write(stringArray1[i]+System.lineSeparator());
		  }
		  writer1.close();
		  
		  int size = updateList.size();
		  String[] stringArray = updateList.toArray(new String[0]);
		  
		  PrintWriter pwriter = new PrintWriter("members.txt");
		  pwriter.print("");
		  pwriter.close();
		  
		  for(int i = 0 ; i < size; i++) {
			  writer.write(stringArray[i]+System.lineSeparator());
		  }
		  writer.close();
		
		l1.removeElement(list.getSelectedValue());
		}
	}
}

